BidMagnet Power BI project
==========================
Needs Power BI Desktop on Windows (recent version).

1. Unzip this folder to C:\BidMagnet_PowerBI\  (then the data path already matches)
   - If you unzip elsewhere: open the project, Home -> Transform data -> Edit parameters
     -> DataFolder = the full path of the "data" folder, ending with a backslash.
2. Double-click BidMagnet.pbip  (if Desktop asks, enable File -> Options -> Preview
   features -> "Power BI Project (.pbip) save option").
3. Home -> Refresh. Both tables load (23,059 tenders, 27,312 results), already linked
   by tender_id, with measures: Tenders, Open Tenders, Total Budget (€), Avg Budget (€),
   Distinct Buyers, Awards, Awarded Value (€), Median Bidders, Avg Bidders,
   % Single-Bid Awards, Median Discount, % Won by SMEs, Distinct Winners.
4. Build the pages (see POWERBI_GUIDE.md in the repo), then File -> Save as -> .pbix
   if you need a single file.

If the project doesn't open, load data/tenders.csv and data/results.csv manually and
paste the measures from POWERBI_GUIDE.md.
